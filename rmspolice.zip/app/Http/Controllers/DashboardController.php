<?php
namespace App\Http\Controllers;

class DashboardController extends Controller
{
    public function index()
    {
        if (auth()->user()->isOperator()) {
            return view('dashboard.operator');
        } else {
            return view('dashboard.admin');
        }
    }
}
