<?php

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Report\ReportController;
use App\Http\Controllers\User\DesignationController;
use App\Http\Controllers\Report\ProgramTypeController;
use App\Http\Controllers\Political\PoliticalPartyController;

Route::get('/', [AuthController::class, 'showLogin'])->name('home');

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);

Route::middleware(['auth', 'isLoggedIn'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Only allow POST method for actual logout
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Handle GET /logout: Redirect back if logged in
    Route::get('/logout', function () {
        return redirect()->back();
    })->name('logout.get');

    // ------- AJAX routes start -------
    Route::get('/ajax/fetch-upazilas-by-seat', [AjaxController::class, 'fetchUpazilasBySeat'])->name('ajax.fetch.upazilas.by.seat');
    Route::get('/ajax/fetch-zones-by-upazila', [AjaxController::class, 'fetchZonesByUpazila'])->name('ajax.fetch.zones.by.upazila');
    Route::get('/ajax/union/{upazila_id}', [AjaxController::class, 'getUnion'])->name('ajax.union');
    Route::get('/ajax/seat-parties', [AjaxController::class, 'getSeatParties'])->name('ajax.seat.parties');
    Route::get('/ajax/seat-party-candidate', [AjaxController::class, 'getSeatPartyCandidate'])->name('ajax.seat.party.candidate');
    Route::get('/ajax/political-party/{id}', [AjaxController::class, 'getPoliticalParty'])->name('ajax.political.party');
    // ------- AJAX routes end -------

    // ------- Custom routes start -------
    // Users
    Route::post('users/toggle-active', [UserController::class, 'toggleActive'])->name('users.toggleActive');
    Route::put('users/{user}/password', [UserController::class, 'userPasswordReset'])->name('users.password.reset');
    Route::get('profile', [UserController::class, 'profile'])->name('profile');
    Route::put('/profile/update', [UserController::class, 'updateProfile'])->name('profile.update');

    // Report
    Route::get('reports/{report}/download', [ReportController::class, 'download'])->name('reports.download');
    Route::get('/reports/{report}/magistrates', [ReportController::class, 'getMagistrates'])->name('reports.magistrates');
    Route::post('/reports/{report}/assign-magistrates', [ReportController::class, 'assignMagistrates'])->name('reports.assignMagistrates');

    // Resource routes
    Route::resource('users', UserController::class);
    Route::resource('designations', DesignationController::class);
    Route::resource('political-parties', PoliticalPartyController::class);
    Route::resource('program-types', ProgramTypeController::class);
    Route::resource('reports', ReportController::class);
    // ------- Custom routes end -------
});

// Handle GET /logout for logged-out users (redirect to login)
Route::get('/logout', function () {
    return redirect()->route('login');
})->name('logout.get');

Route::controller(PasswordController::class)
    ->middleware('guest')
    ->group(function () {
        Route::get('forgot-password', 'showLinkRequestForm')->name('password.request');
        Route::post('forgot-password', 'sendResetLinkEmail')->name('password.email');
        Route::get('reset-password', function () {
            return redirect()->route('password.request');
        })->name('password.reset.request');
        Route::get('reset-password/{token}', 'showResetForm')->name('password.reset');
        Route::post('reset-password', 'reset')->name('password.update');
    });

// ----- Tools for testing ----
// Testing mail server
Route::get('/send-test-email', function () {
    Mail::raw('This is a test email from Laravel 12!', function ($message) {
        $message->to('ashik.ane.doict@gmail.com')->subject('Laravel 12 Gmail SMTP Test');
    });

    return 'Test email sent successfully!';
});

Route::get('/run-command/{slug}', function (string $slug) {
    // ❌ Block completely in production
    // abort_if(app()->environment('production'), 404);

    // // 🔐 Must be logged in
    // abort_unless(auth()->check(), 403);

    // // 🔐 Must be Administrator
    // abort_unless(auth()->user()->role && auth()->user()->role->name === 'Administrator', 403);

    // ✅ Allowed slug → command mapping
    $commands = [
        'optimize-clear'       => 'optimize:clear',
        'migrate'              => 'migrate',
        'migrate-seed'         => 'migrate --seed',
        'migrate-refresh'      => 'migrate:refresh',
        'migrate-refresh-seed' => 'migrate:refresh --seed',
        'migrate-fresh-seed'   => 'migrate:fresh --seed',
    ];

    // abort_unless(array_key_exists($slug, $commands), 404);

    // ▶ Run command
    Artisan::call($commands[$slug]);

    return response()->json([
        'success' => true,
        'slug'    => $slug,
        'command' => $commands[$slug],
        'output'  => Artisan::output(),
    ]);
})->name('run.command');
