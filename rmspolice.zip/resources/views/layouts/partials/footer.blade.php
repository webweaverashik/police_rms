<div id="kt_app_footer" class="app-footer ">
    <!--begin::Footer container-->
    <div class="app-container container-fluid d-flex flex-row flex-center flex-md-stack py-3 justify-content-between">
        <!--begin::Copyright-->
        <div class="text-gray-900">
            <span class="text-muted fw-semibold me-1">{{ date('Y') }} &copy;</span>
            <a href="https://ashikur-rahman.com" target="_blank" class="text-gray-800 text-hover-primary">আশিকুর রহমান</a>
        </div>
        <!--end::Copyright-->
        <!--begin::Menu-->
        <ul class="menu menu-gray-600 menu-hover-primary fw-semibold">
            <li class="menu-item"><a href="#" target="_blank" class="menu-link px-2">PRMS v1.2.9</a></li>
        </ul>
        <!--end::Menu-->
    </div>
    <!--end::Footer container-->
</div>
